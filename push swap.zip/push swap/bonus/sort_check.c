/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_check.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/05 18:14:23 by tamehri           #+#    #+#             */
/*   Updated: 2024/01/05 20:35:29 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "checker.h"

int	is_sorted(t_list **stack_a)
{
	t_list			*tmp;

	tmp = *stack_a;
	while (tmp)
	{
		if (tmp->next && tmp->data > tmp->next->data)
			return (0);
		tmp = tmp->next;
	}
	return (1);
}

void	function(t_list **a, t_list **b, char *line)
{
	if (!ft_strcmp(line, "ra"))
		ra(a);
	else if (!ft_strcmp(line, "rb"))
		rb(b);
	else if (!ft_strcmp(line, "rr"))
		rr(a, b);
	else if (!ft_strcmp(line, "rra"))
		rra(a);
	else if (!ft_strcmp(line, "rrb"))
		rrb(b);
	else if (!ft_strcmp(line, "rrr"))
		rrr(a, b);
	else if (!ft_strcmp(line, "pb"))
		pb(a, b);
	else
		ft_exit(a, b, NULL);
}

void	checker(t_list **a, t_list **b)
{
	char	*line;

	line = NULL;
	while (get_next_line(0, &line) > 0)
	{
		if (!ft_strcmp(line, "sa"))
			sa(a);
		else if (!ft_strcmp(line, "sb"))
			sb(b);
		else if (!ft_strcmp(line, "ss"))
			ss(a, b);
		else if (!ft_strcmp(line, "pa"))
			pa(a, b);
		else
			function(a, b, line);
		free(line);
		line = NULL;
	}
	if (line)
		free(line);
	if (is_sorted(a) && !(*b))
		ft_putstr("OK\n");
	else
		ft_putstr("KO\n");
}
