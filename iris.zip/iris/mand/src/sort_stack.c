/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_stack.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/20 10:25:45 by tamehri           #+#    #+#             */
/*   Updated: 2024/01/13 17:55:47 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

int	is_sorted(t_list **stack_a)
{
	t_list			*tmp;

	if (!(stack_a) || !(*stack_a)->next)
		return (1);
	tmp = *stack_a;
	while (tmp->next)
	{
		if (tmp->data > tmp->next->data)
			return (0);
		tmp = tmp->next;
	}
	return (1);
}

void	sort_stack(t_list **stack_a, t_list **stack_b)
{
	int	size;

	size = ft_lstsize(*stack_a);
	if (is_sorted(stack_a))
	{
		free_stacks(stack_a, stack_b);
		exit(1);
	}
	if (size <= 5)
		simple_sort(stack_a, stack_b, size);
	else
	{
		sort_to_b(stack_a, stack_b);
		sort_to_a(stack_a, stack_b);
	}
	return ;
}
