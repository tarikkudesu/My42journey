/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_algo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/04 14:56:40 by tamehri           #+#    #+#             */
/*   Updated: 2024/01/13 18:17:52 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

t_list	*find_cheapest(t_list **a)
{
	t_list	*tmp;
	t_list	*cheapest;
	
	cheapest = *a;
	tmp = (*a)->next;
	while (tmp)
	{
		if (tmp->cheap < cheapest->cheap)
			cheapest = tmp;
		tmp = tmp->next;
	}
	return (cheapest);
}

int	loop_rrr(t_list **a, t_list **b, t_list *cheapest)
{
	while (cheapest->data != (*a)->data
		&& cheapest->target->data != (*b)->data)
		if (!rrr(a, b))
			return (0);
	while (cheapest->data != (*a)->data)
		if (!rra(a))
			return (0);
	while (cheapest->target->data != (*b)->data)
		if (!rrb(b))
			return (0);
	return (1);
}

int	loop_rr(t_list **a, t_list **b, t_list *cheapest)
{
	while (cheapest->data != (*a)->data
		&& cheapest->target->data != (*b)->data)
		if (!rr(a, b))
			return (0);
	while (cheapest->data != (*a)->data)
		if (!ra(a))
			return (0);
	while (cheapest->target->data != (*b)->data)
		if (!rb(b))
			return (0);
	return (1);
}

int	loopsingle(t_list **a, t_list **b, t_list *cheapest)
{
	if (cheapest->med)
	{
		while (cheapest->data != (*a)->data)
			if (!ra(a))
				return (0);
	}
	else
	{
		while (cheapest->data != (*a)->data)
			if (!rra(a))
				return (0);
	}
	if (cheapest->target->med)
	{
		while (cheapest->target->data != (*b)->data)
			if (!rb(b))
				return (0);
	}
	else
	{
		while (cheapest->target->data != (*b)->data)
			if (!rrb(b))
				return (0);
	}
	return (1);
}

int	move_cheapest(t_list **a, t_list **b, t_list *cheapest)
{
	if (!cheapest->med && !cheapest->target->med)
	{
		if (!loop_rrr(a, b, cheapest))
			return (0);
	}
	else if (cheapest->med && cheapest->target->med)
	{
		if (!loop_rr(a, b, cheapest))
			return (0);
	}
	else
	{
		if (!loopsingle(a, b, cheapest))
			return (0);
	}
	return (1);
}
