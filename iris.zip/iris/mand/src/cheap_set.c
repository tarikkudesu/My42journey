/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cheap_set.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/27 13:56:27 by tamehri           #+#    #+#             */
/*   Updated: 2024/01/13 17:25:38 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

unsigned int	cost_to_top(t_list **stack, t_list **cur)
{
	unsigned int	size;

	size = ft_lstsize(*stack);
	if ((*cur)->position <= size / 2)
		return ((*cur)->position);
	else
		return (size - (*cur)->position);
}

unsigned int	max_value(unsigned int x, unsigned int y)
{
	if (x >= y)
		return (x);
	else
		return (y);
}
