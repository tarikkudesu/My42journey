
void	loop_rrr(t_stack **a, t_stack **b)
{
	while ((*a)->head->data != (*a)->cheapest_node->data
		&& (*b)->head->data != (*b)->cheapest_node->data)
		r_rotate_both(a, b, "rrr");
	while ((*a)->head->data != (*a)->cheapest_node->data)
		r_rotate(a, "rra");
	while ((*b)->head->data != (*b)->cheapest_node->data)
		r_rotate(b, "rrb");
}

void	loop_rr(t_stack **a, t_stack **b)
{
	while ((*a)->head->data != (*a)->cheapest_node->data
		&& (*b)->head->data != (*b)->cheapest_node->data)
		rotate_both(a, b, "rr");
	while ((*a)->head->data != (*a)->cheapest_node->data)
		rotate(a, "ra");
	while ((*b)->head->data != (*b)->cheapest_node->data)
		rotate(b, "rb");
}

void	loop_single(t_stack **a, t_stack **b, int cost_a, int cost_b)
{
	if (cost_a > (*a)->qty / 2)
	{
		while ((*a)->head->data != (*a)->cheapest_node->data)
			r_rotate(a, "rra");
	}
	else
	{
		while ((*a)->head->data != (*a)->cheapest_node->data)
			rotate(a, "ra");
	}
	if (cost_b > (*b)->qty / 2)
	{
		while ((*b)->head->data != (*b)->cheapest_node->data)
			r_rotate(b, "rrb");
	}
	else
	{
		while ((*b)->head->data != (*b)->cheapest_node->data)
			rotate(b, "rb");
	}
}

void	all_top(t_stack **a, t_stack **b)
{
	int		cost_a;
	int		cost_b;

	cost_a = get_pos_in_stack((*a)->cheapest_node, a);
	cost_b = get_pos_in_stack((*b)->cheapest_node, b);
	if (cost_a > (*a)->qty / 2 && cost_b > (*b)->qty / 2)
		loop_rrr(a, b);
	else if (cost_a < (*a)->qty / 2 && cost_b < (*b)->qty / 2)
		loop_rr(a, b);
	else
		loop_single(a, b, cost_a, cost_b);
}