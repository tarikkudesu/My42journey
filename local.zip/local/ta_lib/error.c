/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/06 22:21:28 by tamehri           #+#    #+#             */
/*   Updated: 2024/04/07 12:28:37 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libt.h"

int	terror(t_error _error_message)
{
	if (_error_message == T_ERROR)
		ft_putendl_fd("Error", 2);
	else if (_error_message == T_ERR_MAL)
		ft_putendl_fd("Error malloc", 2);
	else if (_error_message == T_ERR_OPEN)
		perror("open error ");
	else if (_error_message == T_ERR_STRJOIN)
		ft_putendl_fd("Error ft_strjoin", 2);
	else if (_error_message == T_ERR_STRDUP)
		ft_putendl_fd("Error : ft_strdup", 2);
	else if (_error_message == T_ERR_SUBSTR)
		ft_putendl_fd("Error ft_substr", 2);
	else if (_error_message == T_ERR_CALLOC)
		ft_putendl_fd("Error ft_calloc", 2);
	else if (_error_message == T_ERR_SPLIT)
		ft_putendl_fd("Error ft_split", 2);
	else if (_error_message == T_ERR_ATOI)
		ft_putendl_fd("Error ft_atoi", 2);
	else if (_error_message == T_ERR_ITOA)
		ft_putendl_fd("Error ft_itoa", 2);
	return (1);
}

void	terrors(t_error _error_message)
{
	exit(terror(_error_message));
}

int		serror(char *_error_meassage)
{
	ft_putendl_fd(_error_meassage, 2);
	return (1);
}

void	serrors(char *_error_message)
{
	exit(serror(_error_message));
}
