/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/06 23:28:45 by tamehri           #+#    #+#             */
/*   Updated: 2024/04/07 12:35:43 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libt.h"

void	t_free(char *ptr)
{
	if (ptr)
		free(ptr);
	ptr = NULL;
}

void	t_free_int(int **array)
{
	int	i;

	i = -1;
	while (*(array + 1))
		(free(*(array + i)), *(array + i) = NULL);
	(free(array), array = NULL);
}

void	t_free_char(char **array)
{
	int	i;

	i = -1;
	while (*(array + 1))
		(free(*(array + i)), *(array + i) = NULL);
	(free(array), array = NULL);
}

void	free_arr(void **ptr, t_type _to_be_free_type)
{
	if (_to_be_free_type == T_INT)
		t_free_int((int **)ptr);
	else if (_to_be_free_type == T_CHAR)
		t_free_char((char **)ptr);
}
