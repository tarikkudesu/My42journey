/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   talloc.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/04/06 23:37:37 by tamehri           #+#    #+#             */
/*   Updated: 2024/05/10 10:50:31 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libt.h"

void	*talloc(size_t __size)
{
	void	*__ptr;

	__ptr = malloc(__size);
	if (__ptr == NULL)
		return (NULL);
		printf("pointer \033[32m%p\033[0m was allocated, size : \033[32m%ld\033[0m\n", __ptr, __size);
	return (__ptr);
}
