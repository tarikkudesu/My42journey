/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/31 16:54:56 by tamehri           #+#    #+#             */
/*   Updated: 2024/04/07 12:13:14 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libt.h"

void	*ft_calloc(size_t count, size_t size)
{
	void	*r;

	r = malloc(count * size);
	if (!r)
		return (0);
	ft_bzero(r, count * size);
	return (r);
}
