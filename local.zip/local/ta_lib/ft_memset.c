/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tamehri <tamehri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/31 12:01:46 by tamehri           #+#    #+#             */
/*   Updated: 2024/04/07 12:13:14 by tamehri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libt.h"

void	*ft_memset(void *b, int c, size_t len)
{
	while (len--)
		*(unsigned char *)(b + len) = (unsigned char)c;
	return (b);
}
