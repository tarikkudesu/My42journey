#!/bin/bash

# Créer le fichier AppleScript
cat <<EOF > light_mode_script.scpt
tell application "System Events"
    tell appearance preferences
        set dark mode to false
    end tell
end tell
EOF

# Exécuter le fichier AppleScript
osascript light_mode_script.scpt

# Supprimer le fichier AppleScript après utilisation (optionnel)
rm light_mode_script.scpt

