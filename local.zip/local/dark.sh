#!/bin/bash

# Créer le fichier AppleScript
cat <<EOF > dark_mode_script.scpt
tell application "System Events"
    tell appearance preferences
        set dark mode to true
    end tell
end tell
EOF

# Exécuter le fichier AppleScript
osascript dark_mode_script.scpt

# Supprimer le fichier AppleScript après utilisation (optionnel)
rm dark_mode_script.scpt

